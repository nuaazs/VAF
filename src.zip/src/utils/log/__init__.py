# coding = utf-8
# @Time    : 2022-09-05  15:05:21
# @Author  : zhaosheng@nuaa.edu.cn
# @Describe: Log.

from utils.log.log_wraper import logger
from utils.log.log_wraper import err_logger
