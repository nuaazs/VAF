# coding = utf-8
# @Time    : 2022-09-05  15:09:13
# @Author  : zhaosheng@nuaa.edu.cn
# @Describe: Minio.

from utils.oss.upload import upload_file
