# coding = utf-8
# @Time    : 2022-09-05  15:35:09
# @Author  : zhaosheng@nuaa.edu.cn
# @Describe: Test utils.

from utils.test.scores import get_scores
from utils.test.scores import test_wav
from utils.test.scores import self_check
from utils.test.test import test
