# coding = utf-8
# @Time    : 2022-09-05  15:11:50
# @Author  : zhaosheng@nuaa.edu.cn
# @Describe: Phone info utils.

from utils.phone.phone_util import get_phone_info
