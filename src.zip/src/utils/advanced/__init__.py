# coding = utf-8
# @Time    : 2022-09-05  09:47:16
# @Author  : zhaosheng@nuaa.edu.cn
# @Describe: High level abstract functions.

from utils.advanced.general import general
from utils.advanced.general import get_score
from utils.advanced.init_service import init_service
