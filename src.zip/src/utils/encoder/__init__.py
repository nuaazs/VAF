# coding = utf-8
# @Time    : 2022-09-05  15:02:31
# @Author  : zhaosheng@nuaa.edu.cn
# @Describe: models.

from utils.encoder.encoder import similarity
from utils.encoder.encoder import spkreg
from utils.encoder.encode import encode
from utils.encoder.scores import test_wav
