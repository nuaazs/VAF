# coding = utf-8
# @Time    : 2022-09-05  15:34:42
# @Author  : zhaosheng@nuaa.edu.cn
# @Describe: Register utils.

from utils.register.register import register
